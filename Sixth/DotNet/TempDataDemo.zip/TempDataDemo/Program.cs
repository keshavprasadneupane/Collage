var builder = WebApplication.CreateBuilder(args);

// Razor Pages ships with TempData already working out of the box,
// backed by cookies (CookieTempDataProvider) — no Session needed.
builder.Services.AddRazorPages();

var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();

app.MapGet("/", () => Results.Redirect("/Index"));
app.MapRazorPages();

app.Run();
