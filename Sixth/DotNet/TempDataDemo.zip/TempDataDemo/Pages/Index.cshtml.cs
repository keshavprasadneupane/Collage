using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TempDataDemo.Pages;

public class IndexModel : PageModel
{
    [BindProperty]
    public string UserInput { get; set; } = string.Empty;

    public void OnGet()
    {
    }

    public IActionResult OnPostSubmitAndRedirect()
    {
        if (!string.IsNullOrWhiteSpace(UserInput))
        {
            // TempData survives exactly one subsequent request (it's stored
            // in a cookie and marked for deletion as soon as it's read).
            TempData["FlashMessage"] = $"Message passed from Page 1: '{UserInput}' at {DateTime.Now:T}";
        }

        // A redirect is required here — TempData is specifically designed
        // to survive a redirect, unlike ViewData/ViewBag which die with the request.
        return RedirectToPage("/Redirected");
    }
}
