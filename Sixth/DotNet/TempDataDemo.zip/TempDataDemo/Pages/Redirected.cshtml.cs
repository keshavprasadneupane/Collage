using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TempDataDemo.Pages;

public class RedirectedModel : PageModel
{
    public string? ReceivedMessage { get; set; }
    public bool WasKept { get; set; }

    public void OnGet(bool keep = false)
    {
        // Peek() looks at the value WITHOUT marking it for deletion.
        // Reading TempData["key"] directly marks it for deletion after this request.
        var value = TempData.Peek("FlashMessage");

        if (value != null)
        {
            ReceivedMessage = value.ToString();

            if (keep)
            {
                // Keep() tells the framework "don't delete this after all" —
                // it will survive exactly one more request/redirect.
                TempData.Keep("FlashMessage");
                WasKept = true;
            }
            else
            {
                // Actually consume it (mark for deletion) since we're not keeping it.
                _ = TempData["FlashMessage"];
            }
        }
    }
}
